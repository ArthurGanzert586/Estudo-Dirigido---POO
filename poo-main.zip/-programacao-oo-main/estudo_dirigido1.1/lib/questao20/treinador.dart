import 'pokemon.dart';

class Treinador {
  String nome;
  Pokemon pokemon1;
  Pokemon pokemon2;
  Pokemon pokemon3;

  Treinador(this.nome, this.pokemon1, this.pokemon2, this.pokemon3) {
    if (nome.isEmpty) {
      throw Exception("Nome do treinador nao pode ser vazio");
    }
  }

  void exibirTime() {
    print("Treinador: $nome");
    print("===== TIME =====");

    pokemon1.exibir();
    pokemon2.exibir();
    pokemon3.exibir();
  }

  int calcularPoderTotal() {
    return pokemon1.nivel +
        pokemon2.nivel +
        pokemon3.nivel;
  }

  void pokemonMaisForte() {
    Pokemon maisForte = pokemon1;

    if (pokemon2.nivel > maisForte.nivel) {
      maisForte = pokemon2;
    }

    if (pokemon3.nivel > maisForte.nivel) {
      maisForte = pokemon3;
    }

    print("Pokemon mais forte:");
    maisForte.exibir();
  }
}